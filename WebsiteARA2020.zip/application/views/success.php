<div class="container-designed">

    <div class="apple-window-designed">
       
       <div data-aos="zoom-in">

          <div class="header-designed">
              <ul style="margin: 0;">
                  <li class="button-circle-designed" style="background-color: #AC8FBC;">
                  </li>
                  <li class="button-circle-designed" style="background-color: #AAD8B6;">
                  </li>
                  <li class="button-circle-designed" style="background-color: #E7A996;">
                  </li>
              </ul>
          </div>

          <div class="content-designed">
              <div class="row">
                  <div class="col s12 center-align">
                    <img class="responsive-img" src="<?php echo base_url(); ?>assets/images/berhasil.png">
                  </div>
              </div>
              <form action="<?php echo base_url();?>">
                  <div class="row">
                      <div class="center-align">
                          <button class="btn waves-effect waves-light center-align submit-button-form-designed"
                              type="submit" style="background-color: #64a0cc;">Kembali
                          </button>
                      </div>
                  </div>
              </form><br>
          </div>  
          <br>
    </div>
</div>
        