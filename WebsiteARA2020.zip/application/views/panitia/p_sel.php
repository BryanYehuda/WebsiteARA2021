<div class="col s12">
    <div class="text-center row" style="font-size: xx-large;">
        <div class="col-xs-12"><a href="<?= base_url('panitiaaraonly/webinar') ?>">Webinar</a></div>

        <div class="col-xs-12"><a href="<?= base_url('panitiaaraonly/ctf') ?>">CTF</a></div>

        <div class="col-xs-12"><a href="<?= base_url('panitiaaraonly/iot') ?>">IOT</a></div>

        <div class="col-xs-12"><a href="<?= base_url('panitiaaraonly/olim') ?>">Olimpiade</a></div>
    </div>
</div>