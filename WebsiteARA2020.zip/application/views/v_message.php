<div class="container-designed">

    <div class="apple-window-designed">

        <div data-aos="zoom-in">

            <div class="header-designed">
                <ul style="margin: 0;">
                    <li class="button-circle-designed" style="background-color: #AC8FBC;">
                    </li>
                    <li class="button-circle-designed" style="background-color: #AAD8B6;">
                    </li>
                    <li class="button-circle-designed" style="background-color: #E7A996;">
                    </li>
                </ul>
            </div>

            <div class="content-designed">
                <div class="row">
                    <div class="col s12 center-align">
                        <h3 draggable="false">
                            <?php echo str_replace('\n', '<br>', $thetitle); ?>
                        </h3>
                    </div>
                    <div class="col s12 center-align">
                        <h4>
                            <?php echo str_replace('\n', '<br>', $themessage); ?>
                        </h4>
                    </div>
                </div>
                <br>
            </div>
            <br>
        </div>
    </div>