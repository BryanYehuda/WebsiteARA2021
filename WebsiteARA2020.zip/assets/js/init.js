(function($) {
    $(function() {

        $('.sidenav').sidenav();
        $('.modal').modal();

    });
})(jQuery);